# es6-oraclejet-redux

## Comming soon

### For devs, start the server: `node_modules/.bin/babel-node tools/run common/serve src --es6`