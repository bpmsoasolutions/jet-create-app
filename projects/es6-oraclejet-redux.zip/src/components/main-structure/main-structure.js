import template from 'text!./main-structure.html';

class viewModel {
    constructor(){}
}

export default { viewModel, template };
