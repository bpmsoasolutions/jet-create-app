import $ from 'jquery';
import ko from 'knockout';
import template from 'text!./footer.html'

class viewModel { }

export default { viewModel, template };
